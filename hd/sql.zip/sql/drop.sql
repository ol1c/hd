USE VisitorTrack

DELETE FROM Exhibition_visits;
DELETE FROM Exhibit_Exhibitions;
DELETE FROM Exhibitions;
DELETE FROM Exhibits;
DELETE FROM Rooms;
DELETE FROM Visitors;

DROP TABLE Exhibition_visits;
DROP TABLE Exhibit_Exhibitions;
DROP TABLE Exhibitions;
DROP TABLE Exhibits;
DROP TABLE Rooms;
DROP TABLE Visitors;
GO